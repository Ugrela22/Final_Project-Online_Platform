from django.contrib import admin
from .models import Category, Brand, Product, Review, Cart, CartItem, ProductImage


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


class ProductAdmin(admin.ModelAdmin):
    inlines = [ProductImageInline]


admin.site.register(Category)
admin.site.register(Brand)
admin.site.register(Product, ProductAdmin)
admin.site.register(Review)
admin.site.register(Cart)
admin.site.register(CartItem)