from django.urls import path
from .views import *

urlpatterns = [
    path('', ProductList.as_view(), name='home'),              # / → მთავარი გვერდი
    path('product/<int:pk>/', ProductDetail.as_view(), name='product_detail'),  # /product/5/ → პროდუქტი ID=5
    path('add-to-cart/<int:pk>/', AddToCart.as_view(), name='add_to_cart'),     # /add-to-cart/5/ → კალათაში დამატება
    path('cart/', CartView.as_view(), name='cart'),            # /cart/ → კალათა
    path('update-item/<int:pk>/', UpdateCartItem.as_view(), name='update_item'),# /update-item/3/ → რაოდენობის შეცვლა
    path('delete-item/<int:pk>/', DeleteCartItem.as_view(), name='delete_item'),# /delete-item/3/ → კალათიდან წაშლა
    path('register/', RegisterPage.as_view(), name='register'),# /register/ → რეგისტრაცია
    path('buy/', BuyView.as_view(), name='buy'),               # /buy/ → შეძენა
    path('login/', CustomLoginView.as_view(), name='login'),   # /login/ → ავტორიზაცია
    path('logout/', CustomLogoutView.as_view(), name='logout'),# /logout/ → გამოსვლა
]