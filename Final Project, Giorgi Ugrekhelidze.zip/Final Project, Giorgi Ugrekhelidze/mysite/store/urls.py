from django.urls import path
from .views import *

urlpatterns = [
    path('', ProductList.as_view(), name='home'),
    path('product/<int:pk>/', ProductDetail.as_view(), name='product_detail'),
    path('add-to-cart/<int:pk>/', AddToCart.as_view(), name='add_to_cart'),
    path('cart/', CartView.as_view(), name='cart'),
    path('update-item/<int:pk>/', UpdateCartItem.as_view(), name='update_item'),
    path('delete-item/<int:pk>/', DeleteCartItem.as_view(), name='delete_item'),
    path('register/', RegisterPage.as_view(), name='register'),
    path('buy/', BuyView.as_view(), name='buy'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),
]