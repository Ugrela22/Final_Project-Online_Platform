from django.shortcuts import redirect
from django.views.generic import *
from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.db.models import Avg, Count
from django.contrib import messages
from django.contrib.auth import logout
from django.views import View
from .models import *

# რეგისტრაციის გვერდი
class RegisterPage(FormView):
    template_name = 'store/register.html'
    form_class = UserCreationForm
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        form.save()
        messages.success(self.request, "Register successful!")
        return super().form_valid(form)

# ავტორიზაციის გვერდი
class CustomLoginView(LoginView):
    template_name = 'store/login.html'

    def get_success_url(self):
        return reverse_lazy('home')

# გამოსვლა
class CustomLogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('home')

# მთავარი გვერდი — პროდუქტების სია ფილტრებით, გვერდზე მაქსიმუმ 6 პროდუქტი
class ProductList(ListView):
    model = Product
    template_name = 'store/index.html'
    context_object_name = 'products'
    paginate_by = 6

    def get_queryset(self):
        # ყველა პროდუქტი + საშუალო რეიტინგი + review-ების რაოდენობა
        queryset = Product.objects.annotate(
            avg_rating=Avg('reviews__rating'),
            review_count=Count('reviews')
        )

        search = self.request.GET.get('search')
        category = self.request.GET.get('category')
        brand = self.request.GET.get('brand')
        min_price = self.request.GET.get('min_price')
        max_price = self.request.GET.get('max_price')
        min_rating = self.request.GET.get('min_rating')

        if search:
            queryset = queryset.filter(name__icontains=search)
        if category:
            queryset = queryset.filter(category__id=category)
        if brand:
            queryset = queryset.filter(brand__id=brand)
        if min_price:
            queryset = queryset.filter(price__gte=min_price)
        if max_price:
            queryset = queryset.filter(price__lte=max_price)
        if min_rating:
            queryset = queryset.filter(avg_rating__gte=min_rating)

        return queryset.order_by('-published') # უახლესი პირველი

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['categories'] = Category.objects.all()
        context['brands'] = Brand.objects.all()
        return context

# პროდუქტის დეტალური გვერდი
class ProductDetail(DetailView):
    model = Product
    template_name = 'store/product_detail.html'
    context_object_name = 'product'

    # logged in არ არის → login გვერდზე გადაიყვანე
    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        product = self.get_object()
        rating = request.POST.get('rating')
        comment = request.POST.get('comment')
        full_name = request.POST.get('full_name', '').strip()
        if rating and comment and full_name:
            Review.objects.create(
                product=product,
                user=request.user,
                full_name=full_name,
                rating=int(rating),
                comment=comment
            )
        return redirect('product_detail', pk=product.pk)

# კალათაში დამატება — logged in არ არის → login გვერდზე
class AddToCart(LoginRequiredMixin, View):
    def get(self, request, pk):
        product = Product.objects.get(id=pk)
        cart, created = Cart.objects.get_or_create(user=request.user)
        item, created = CartItem.objects.get_or_create(cart=cart, product=product)

        if not created:
            item.quantity += 1
            item.save()
        else:
            item.quantity = 1
            item.save()

        return redirect('cart')

# კალათის გვერდი — ნივთები + ჯამური ფასი
class CartView(LoginRequiredMixin, ListView):
    template_name = 'store/cart.html'
    context_object_name = 'items'

    def get_queryset(self):
        cart, created = Cart.objects.get_or_create(user=self.request.user)
        return cart.items.select_related('product')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        total = sum(item.product.price * item.quantity for item in context['items'])
        context['total'] = total
        return context

# კალათაში რაოდენობის განახლება — stock-ზე მეტის შეკვეთა შეუძლებელია
class UpdateCartItem(LoginRequiredMixin, View):
    def post(self, request, pk):
        item = CartItem.objects.get(id=pk, cart__user=request.user)
        try:
            quantity = int(request.POST.get('quantity'))
        except (TypeError, ValueError):
            quantity = item.quantity
        if quantity > 0 and quantity <= item.product.stock:
            item.quantity = quantity
            item.save()
        return redirect('cart')

# კალათიდან ნივთის წაშლა
class DeleteCartItem(LoginRequiredMixin, View):
    def get(self, request, pk):
        item = CartItem.objects.get(id=pk, cart__user=request.user)
        item.delete()
        return redirect('cart')

# შეძენა — stock შემოწმება → ჩამოჭრა → კალათის გაწმენდა
class BuyView(LoginRequiredMixin, View):
    def post(self, request):
        try:
            cart = Cart.objects.get(user=request.user)
        except Cart.DoesNotExist:
            return redirect('cart')

        items = cart.items.select_related('product')

        if not items.exists():
            return redirect('cart')

        for item in items:
            if item.quantity > item.product.stock:
                messages.error(request, f"Not enough stock for {item.product.name}")
                return redirect('cart')

        for item in items:
            product = item.product
            product.stock -= item.quantity
            product.save()

        items.delete()
        messages.success(request, "Purchase completed successfully!")
        return redirect('home')